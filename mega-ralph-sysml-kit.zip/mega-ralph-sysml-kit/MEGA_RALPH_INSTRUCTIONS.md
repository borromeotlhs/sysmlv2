# Mega Ralph Loop Instructions

## What You Are Running

This kit runs Claude Code in a repeated build/test/repair loop to create an MVP SysML v2 generation toolchain.

The MVP includes:

```text
validator
rule extractor
IR generator
renderer
batch pipeline
corpus builder
tests
fixtures
docs
```

## Why This Exists

The long-term goal is to generate many valid SysML v2 examples for training or testing. The immediate goal is an MVP that can:

```text
1. Generate structured model IR.
2. Render that IR into .sysml text.
3. Validate the .sysml.
4. Save valid/invalid examples.
5. Build JSONL training corpora.
```

## Run

```bash
./ralph/mega_ralph.sh
```

## Main Task File

Claude Code receives this task:

```text
tasks/mega_task.md
```

## Subagents

The project includes project-local Claude Code subagents in:

```text
.claude/agents/
```

They are specialized for:

```text
sysml-validator-engineer
grammar-rule-extractor
ir-generator-engineer
sysml-renderer-engineer
corpus-pipeline-engineer
integration-reviewer
```

Claude Code should delegate to these agents where useful.

## The Check Command

The loop uses:

```bash
./ralph/run_mvp_checks.sh
```

That script checks for the expected MVP files and runs available tests. Claude Code should improve the code until that command passes.

## Manual Escape Hatch

You can run the same task interactively:

```bash
claude
```

Then paste:

```text
Read tasks/mega_task.md and execute it. Use the project subagents in .claude/agents where appropriate. Keep going until ./ralph/run_mvp_checks.sh passes.
```

## Work-Safety Notes

Use a fresh branch:

```bash
git checkout -b mega-ralph-sysml-mvp
```

Review `.claude/settings.json` before running in a work environment. The settings are intentionally conservative and deny common destructive shell patterns.
